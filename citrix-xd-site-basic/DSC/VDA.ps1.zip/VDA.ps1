#
# VDA.ps1
#
configuration VDA 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$DomainControllerIp,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

	    [String[]]$Packages=@(),

	    [Hashtable[]]$PublishedApplications=@(),

	    [String]$StoreFrontUrl=$null,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration -ModuleVersion 1.1
    
    Import-DscResource -ModuleName CitrixXenDesktopAutomation, CitrixMarketplace, cChoco, xNetworking

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    $gracePath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod"
	
	$zoneMapPath = "HKEY_LOCAL_MACHINE\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\*.$DomainName"
	$zoneMapName = "https"
	$zoneMapValue = 2

	$studioMsc = "C:\Program Files\Citrix\Desktop Studio\Studio.msc"

	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
			ConfigurationMode = "ApplyOnly"
        } 

	    xDnsServerAddress DnsServerAddress
        {
            Address        = $DomainControllerIp
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
        }

		if($Packages)
		{
			cChocoInstaller Install
			{
				InstallDir = "c:\Nuget"
				DependsOn = "[xDnsServerAddress]DnsServerAddress" 
			}
			
			foreach($i in 0..($Packages.Length - 1))
			{
				cChocoPackageInstaller "package$i"
				{
					Name = $Packages[$i]
					DependsOn = "[cChocoInstaller]Install"
				}
			}

			$vdaDependencies = 0..($Packages.Length - 1) | %{ "[cChocoPackageInstaller]package$_" }
		}
		else
		{
			$vdaDependencies = "[xDnsServerAddress]DnsServerAddress"
		}


        Citrix_XenDesktopVDA VDACatalog
        {
            XenDesktopController = $DeliveryController
            CatalogName = "Administrative"
            DeliveryGroupName = "Administrative"
            PSDscRunAsCredential = $DomainCreds
            Users = @($DomainCreds.UserName)
            PublishedApplications = $PublishedApplications | ConvertTo-Json
			StoreFrontUrl = $StoreFrontUrl
            DependsOn = $vdaDependencies
        }
		
		Citrix_XenDesktopStudioController StudioSetup
        {
			XenDesktopController = $DeliveryController
			StudioMsc = $studioMsc
            DependsOn = "[Citrix_XenDesktopVDA]VDACatalog" 
        }
        
        Citrix_MarketplaceStatus Status
        {
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
			MachineName = $env:COMPUTERNAME
			Status = "Succeeded"
            DependsOn = "[Citrix_XenDesktopStudioController]StudioSetup" 
        }
    }
} 
