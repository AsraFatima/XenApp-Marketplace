. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

$trustCertsCode = @"
	using System.Net;
	using System.Security.Cryptography.X509Certificates;
	public class TrustAllCertsPolicy : ICertificatePolicy {
		public bool CheckValidationResult(
			ServicePoint srvPoint, X509Certificate certificate,
			WebRequest request, int certificateProblem) {
			return true;
		}
	}
"@

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)

	$returnValue = @{
        NetscalerIP = $NetscalerIP
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)
	
	$VirtualServerIP = $NetscalerIP
	$LDAPLoginName = "sAMAccountName"
	
	$username = $NetscalerCredential.UserName
	$password = $NetscalerCredential.GetNetworkCredential().Password

	$domainUsername = $DomainCredential.UserName
	$domainPassword = $DomainCredential.GetNetworkCredential().Password

    $certPassword = $CertificatePassword.GetNetworkCredential().Password

	$domainBase = [string]::Join(",", ($DomainName.Split(".") | %{"dc=$_"}))
	
	$certName = "certificate"
	
	Set-Protocol "HTTP"

	$session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password

	Enable-NSVPXFeature -NSIP $NetScalerIP -Features "sslvpn ssl responder loadbalancing" -WebSession $session

	Invoke-NetscalerSSHRaw -Hostname $NetscalerIP -Username $username -Password $password -Commands "add ssl certKey ns-server-certificate -cert ns-server.cert -key ns-server.key"

	Set-Protocol "HTTPS"
	
	Add-Type $trustCertsCode
	
	[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
	
	Add-DNSServer -NSIP $NetScalerIP -DNSServerIP $DomainController -WebSession $session

	try
	{
		Add-CertKeyPair -NSIP $NetScalerIP -CertKeyName $certName -CertPath "certificate.pem" -KeyPath "certificate.pem" -CertKeyFormat PEM -Password $certPassword -WebSession $session 
	}
	catch 
	{
		Write-Verbose "No user provided certificate, using Netscaler self-signed"
		
		$certName = "ns-server-certificate"
	}
	
	Add-LDAPAction -NSIP $NetScalerIP -LDAPActionName "$($DomainController)_LDAP" -LDAPServerIP "$($DomainController)" -LDAPBaseDN $($domainBase) -LDAPBindDN "$domainUsername@$($DomainName)" -LDAPBindDNPassword $($domainPassword) -LDAPLoginName $($LDAPLoginName) -WebSession $session | out-null
	Add-LDAPPolicy -NSIP $NetScalerIP -LDAPActionName "$($DomainController)_LDAP" -LDAPPolicyName "$($DomainController)_LDAP_pol" -LDAPRuleExpression NS_TRUE -WebSession $session

	Add-VServer -NSIP $NetScalerIP -VServerName $($VirtualServerName) -VServerIP $($VirtualServerIP) -VServerPort $VirtualServerPort -WebSession $session
	New-VServeSSLCertKeyBinding -NSIP $NetScalerIP -CertKeyName $certName -VServerName $($VirtualServerName) -WebSession $session
	New-VServerLDAPPolicyBinding -NSIP $NetScalerIP -VServerName $($VirtualServerName) -LDAPPolicyName "$($DomainController)_LDAP_pol" -WebSession $session
	
	Set-NetScalerSFStore -NSIP $($NetScalerIP) -VirtualServerName $($VirtualServerName) -VirtualServerIP $($VirtualServerIP) -StoreFrontServer $StorefrontServer -STAServerURL "https://$DeliveryController" -SingleSignOnDomain $($DomainName) -WebSession $session|out-null

	Set-UItheme -NSIP $($NetScalerIP) -Theme GreenBubble -WebSession $session

	Enable-NSVPXMode -NSIP $NetScalerIP -Modes "mbf" -WebSession $session

	# Set up HTTP forwarding

	Add-ResponderAction -NSIP $NetScalerIP -Name http_to_https -Type redirect -Target '"https:" + "//" + HTTP.REQ.HOSTNAME.HTTP_URL_SAFE + HTTP.REQ.URL.PATH_AND_QUERY.HTTP_URL_SAFE' -WebSession $session
	Add-ResponderPolicy -NSIP $NetScalerIP -Name http_to_https_pol -ActionName http_to_https -UndefinedAction RESET -Expression HTTP.REQ.IS_VALID -WebSession $session
	Add-Monitor -NSIP $NetScalerIP -MonitorName localhost_ping -Type PING -destIP "127.0.0.1" -WebSession $session -LRTM Enabled
	Add-Server -NSIP $NetScalerIP -Name Dummy_server -IPaddress "1.2.3.4" -WebSession $session
	Add-Service -NSIP $NetScalerIP -name Always_UP_Service -ServerName "Dummy_server" -ServiceType HTTP -Port $ForwardServerPort -WebSession $session
	Add-MonitorServiceBinding -NSIP $NetScalerIP -ServiceName Always_UP_Service -MonitorName localhost_ping -WebSession $session
	Add-LBVserver -NSIP $NetScalerIP -Name http_server -ServiceType HTTP -IPAddress $NetScalerIP -port $ForwardServerPort -persistenceType COOKIEINSERT -timeout 0 -cltTimeout 180 -WebSession $session
	Add-LBVServerServiceBinding -NSIP $NetScalerIP -LBVServerName http_server -ServiceName Always_UP_service -WebSession $session
	Add-LBVServerPolicyBinding -NSIP $NetScalerIP -LBVServerName http_server -PolicyName http_to_https_pol -Priority 1 -GotoPriorityExpression "END" -WebSession $session
	
	# Expect underlying connection to close
	try {
		Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session -ErrorAction SilentlyContinue | Out-Null
	} catch { }

	Start-Sleep -Seconds (60*2)
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$ForwardServerPort
	)
	
	$VirtualServerIP = $NetscalerIP

	$username = $NetscalerCredential.UserName
	$password = $NetscalerCredential.GetNetworkCredential().Password

	Set-Protocol "HTTP"

	$session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password
	$json = Get-DNSServer -NSIP $NetscalerIP -WebSession $session
	
	return ($json -and (Get-Member -inputobject $json -name "dnsnameserver" -Membertype Properties) -and (-not (($json.dnsnameserver | ?{$_.ip -match $DomainController }) -eq $null)) )
}

Export-ModuleMember -Function *-TargetResource

