#
# StorefrontJoin.ps1
#
configuration StorefrontJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Parameter(Mandatory)]
        [String]$NetscalerIP,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$StorefrontServer,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$VirtualServerName,

        [Parameter(Mandatory)]
        [String]$GatewayName,

        [Parameter(Mandatory)]
        [String]$SiteName,

        [Parameter(Mandatory)]
        [String]$ThemeUri,

        [Parameter(Mandatory)]
        [String]$HTML5Mode,

        [Parameter(Mandatory)]
        [String]$FQDN,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [Int]$VirtualServerPort,

        [Parameter(Mandatory)]
        [Int]$ForwardServerPort,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, xWindowsUpdate, CitrixNetscaler , CitrixXenDesktopAutomation, xCertificate, xWebAdministration

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    if(-not $FQDN)
    {
        $FQDN = $DeploymentFQDN
    }

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = "$($StorefrontServer).$($DomainName)"
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $StorefrontServer; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }

        Citrix_XenDesktopStorefront Storefront
        {
            XenDesktopController = $DeliveryController
            StorefrontServer = "$($StorefrontServer).$($DomainName)"
            FQDN = $FQDN
            HTML5Mode = $HTML5Mode
            GatewayName = $GatewayName
            SiteName = $SiteName
            Transport = "HTTPS"
            NetscalerIp = $NetscalerIP
            Port = 443
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[xWebSite]DefaultWebSite" 
        }
    }
} 
