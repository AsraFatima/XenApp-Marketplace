#
# StorefrontJoin.ps1
#
configuration StorefrontJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Parameter(Mandatory)]
        [String]$NetscalerIP,

        [Parameter(Mandatory)]
        [String]$License,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$CertificatePassword,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$StorefrontServer,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$VirtualServerName,

        [Parameter(Mandatory)]
        [String]$GatewayName,

        [Parameter(Mandatory)]
        [String]$SiteName,

        [Parameter(Mandatory)]
        [String]$ThemeUri,

        [Parameter(Mandatory)]
        [String]$HTML5Mode,

        [Parameter(Mandatory)]
        [String]$GatewayFQDN,

        [Parameter(Mandatory)]
        [String]$DeploymentFQDN,

        [Parameter(Mandatory)]
        [Int]$VirtualServerPort,

        [Parameter(Mandatory)]
        [Int]$ForwardServerPort,

        [Parameter(Mandatory)]
        [String]$EmailAddress,

        [Parameter(Mandatory)]
        [String]$ACMEServer,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, CitrixNetscaler , CitrixXenDesktopAutomation, CitrixMarketplace, xCertificate, xWebAdministration, ACMEPowerShell, ACMECertificate

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $iisPath = "C:\\inetpub\\wwwroot"
	$certFile = "C:\Vault\cert.pem"
	$keyFile = "C:\Vault\key.pem"
	$pairFile = "C:\Vault\pair.pem"
	$vaultPath = "C:\Vault"
	
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
		
		Citrix_MarketplaceDomain Domain
        { 
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[Citrix_MarketplaceDomain]Domain" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }
        
		ACME_CertificateRequest CertRequest
        { 
            ACMEServer = $AcmeServer
            CommonName = $GatewayFQDN
            EmailAddress = $EmailAddress
            CertificatePassword = $CertificatePassword
            VaultPath = $vaultPath
            CertPath = $certFile
            KeyPath = $keyFile
			PairPath = $pairFile
            IISPath = $iisPath
            DependsOn = "[xComputer]DomainJoin" 
        }

        Citrix_NetscalerDataFile License 
        {
            Filename = "/nsconfig/license/license.lic"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $License
            Reboot = $true
            Ensure = "Present"
            DependsOn = "[ACME_CertificateRequest]CertRequest" 
        }
        
        Citrix_NetscalerRemoteFile Theme 
        {
            Filename = "/var/netscaler/gui/themes/receivertheme.tar.gz"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            FileUri = $ThemeUri
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerDataFile]License" 
        }

        Citrix_NetscalerLocalFile Certificate 
        {
            Filename = "/nsconfig/ssl/certificate.pem"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            LocalPath = $pairFile
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerRemoteFile]Theme"
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = "$($StorefrontServer).$($DomainName)"
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[Citrix_NetscalerLocalFile]Certificate"
        }

        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $StorefrontServer; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }

        Citrix_NetscalerConfigureXD NSConfig 
        {
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            DomainCredential = $Admincreds
            CertificatePassword = $CertificatePassword
            DomainName = $DomainName
            DomainController= $DomainController
            StorefrontServer = "$($StorefrontServer).$($DomainName)"
            DeliveryController = $DeliveryController
            VirtualServerName = $VirtualServerName
            VirtualServerPort = $VirtualServerPort
            ForwardServerPort = $ForwardServerPort
            DependsOn = "[xWebSite]DefaultWebSite"
        }

        Citrix_XenDesktopStorefront Storefront
        {
            XenDesktopController = $DeliveryController
            StorefrontServer = "$($StorefrontServer).$($DomainName)"
            FQDN = $GatewayFQDN
            HTML5Mode = $HTML5Mode
            GatewayName = $GatewayName
            SiteName = $SiteName
            Transport = "HTTPS"
            NetscalerIp = $NetscalerIP
            Port = 443
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_NetscalerConfigureXD]NSConfig" 
        }

		Citrix_MarketplaceEmail Email
        {
            DeploymentFQDN = $DeploymentFQDN
            GatewayFQDN = $GatewayFQDN
            EmailAddress = $EmailAddress
            DependsOn = "[Citrix_XenDesktopStorefront]Storefront" 
        }

		if($ACMEServer -match "staging")
		{
			Script RdGrace
	        {
				SetScript = {
					$encodedCer = "MIIDETCCAfmgAwIBAgIJAJzxkS6o1QkIMA0GCSqGSIb3DQEBCwUAMB8xHTAbBgNVBAMMFGhhcHB5IGhhY2tlciBmYWtlIENBMB4XDTE1MDQwNzIzNTAzOFoXDTI1MDQwNDIzNTAzOFowHzEdMBsGA1UEAwwUaGFwcHkgaGFja2VyIGZha2UgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDCCkd5mgXFErJ3F2M0E9dw+Ta/md5i8TDId01HberAApqmydG7UZYF3zLTSzNjlNSOmtybvrSGUnZ9r9tSQcL8VM6WUOM8tnIpiIjEA2QkBycMwvRmZ/B2ltPdYs/R9BqNwO1g18GDZrHSzUYtNKNeFI6Glamj7GK2Vr0SmiEamlNIR5ktAFsEErzf/d4jCF7sosMsJpMCm1p58QkP4LHLShVLXDa8BMfVoI+ipYcA08iNUFkgW8VWDclIDxcysa0psDDtMjX3+4aPkE/cefmP+1xOfUuDHOGV8XFynsP4EpTfVOZr0/g9gYQ7ZArqXX7GTQkFqduwPm/w5qxSPTarAgMBAAGjUDBOMB0GA1UdDgQWBBT7eE8S+WAVgyyfF380GbMuNupBiTAfBgNVHSMEGDAWgBT7eE8S+WAVgyyfF380GbMuNupBiTAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IBAQAd9Da+Zv+TjMv7NTAmliqnWHY6d3UxEZN3hFEJ58IQVHbBZVZdW7zhRktBvR05Kweac0HJeK91TKmzvXl21IXLvh0gcNLU/uweD3no/snfdB4OoFompljThmglzBqiqWoKBJQrLCA8w5UB+ReomRYd/EYXF/6TAfzm6hr//Xt5mPiUHPdvYt75lMAovRxLSbF8TSQ6b7BYxISWjPgFASNNqJNHEItWsmQMtAjjwzb9cs01XH9pChVAWn9LoeMKa+SlHSYrWG93+EcrIH/dGU76uNOiaDzBSKvaehG53h25MHuO1anNICJvZovWrFo4Uv1EnkKJm3vJFe50eJGhEKlx"
					$binaryCer = [Convert]::FromBase64String($encodedCer)

					$pfx = new-object System.Security.Cryptography.X509Certificates.X509Certificate2
					$pfx.import($binaryCer)

					$store = new-object System.Security.Cryptography.X509Certificates.X509Store(
						[System.Security.Cryptography.X509Certificates.StoreName]::Root,
						"localmachine"
					)

					$store.open("MaxAllowed")
					$store.add($pfx)
					$store.Close()
				}
				TestScript = { 
					Test-Path "Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46"
				}
				GetScript = { 
					return @{ Key = "Test-Path Cert:\localmachine\Root\5F5968E72FFD87450DD50E5EE96A1B793F110D46" }
				}          
			}
		}
    }
} 
