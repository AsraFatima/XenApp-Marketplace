#
# ADCreate.ps1
#
configuration ADCreate 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        
        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
            DependsOn = "[WindowsFeature]DNS"
        }  

        Script Debugger 
        {
            SetScript = { get-dnsclientserveraddress | Out-String | write-verbose }	
            TestScript = { return $false }	
            GetScript = { Write-Verbose "Testing" }	
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
             DependsOn = "[Script]Debugger"
        }

        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[cDiskNoRestart]ADDataDisk" 
        } 

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = (Get-NetAdapter | ?{$_.name -match "Ethernet" } | %{$_.Name} | select -first 1)
            AddressFamily  = 'IPv4'
            DependsOn = "[xADDomain]FirstDS" 
        }
    }
}