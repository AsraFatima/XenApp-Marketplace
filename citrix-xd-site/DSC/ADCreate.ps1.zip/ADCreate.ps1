#
# ADCreate.ps1
#
configuration ADCreate 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDisk, xNetworking, cDisk, xAdcsDeployment
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        
        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
            DependsOn = "[WindowsFeature]DNS"
        }  

        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
            DependsOn = "[WindowsFeature]ADDSInstall"
        }      

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
             DependsOn = "[WindowsFeature]ADDSTools"
        }

        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitforDisk]Disk2"
        }

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[cDiskNoRestart]ADDataDisk" 
        } 

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = (Get-NetAdapter | ?{$_.name -match "Ethernet" } | %{$_.Name} | select -first 1)
            AddressFamily  = 'IPv4'
            DependsOn = "[xADDomain]FirstDS" 
        }

        WindowsFeature ADCS-Cert-Authority 
        { 
            Ensure = 'Present' 
            Name = 'ADCS-Cert-Authority'
            DependsOn = "[xDnsServerAddress]DnsServerAddress"
        } 

        xADCSCertificationAuthority ADCS 
        { 
            Ensure = 'Present' 
            Credential = $DomainCreds 
            CAType = 'EnterpriseRootCA' 
            CACommonName = 'DomainCA'
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority'               
        } 

        WindowsFeature ADCS-Web-Enrollment 
        { 
            Ensure = 'Present' 
            Name = 'ADCS-Web-Enrollment' 
            DependsOn = '[WindowsFeature]ADCS-Cert-Authority' 
        } 

        xADCSWebEnrollment CertSrv 
        { 
            Ensure = 'Present' 
            Name = 'CertSrv' 
            Credential = $DomainCreds
            DependsOn = '[WindowsFeature]ADCS-Web-Enrollment','[xADCSCertificationAuthority]ADCS' 
        }  
    }
}