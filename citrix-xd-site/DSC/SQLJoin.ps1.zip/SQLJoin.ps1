#
# SQLJoin.ps1
#
configuration SQLJOin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    $SqlDomainName = $DomainName.split(".")[0].ToUpper()

    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xSql, xNetworking

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SqlDomainCreds = New-Object System.Management.Automation.PSCredential ("${SqlDomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "1433"
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin" 
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "5022"
            Ensure = "Present"
            DependsOn = "[xFirewall]DatabaseEngineFirewallRule" 
        }

        xFirewall ListenerFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "59999"
            Ensure = "Present"
            DependsOn = "[xFirewall]DatabaseMirroringFirewallRule" 
        }

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $SqlDomainCreds.UserName
            Password = $Admincreds
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
            DependsOn = "[xFirewall]ListenerFirewallRule" 
        }

        xSqlServer ConfigureSqlServer
        {
            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $SqlDomainCreds
            ServiceCredential = $SqlDomainCreds
            MaxDegreeOfParallelism = 1
            FilePath = "C:\DATA"
            LogPath = "C:\LOG"
            DomainAdministratorCredential = $SqlDomainCreds
            DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"
        }
    }
} 
