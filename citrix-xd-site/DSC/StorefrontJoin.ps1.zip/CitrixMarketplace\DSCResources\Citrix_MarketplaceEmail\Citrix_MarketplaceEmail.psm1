$domainUrl = "http://citrixxenappconfig.azurewebsites.net/api/domain"
$emailUrl = "http://citrixxenappconfig.azurewebsites.net/api/email"

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$EmailAddress
	)

	$returnValue = @{
        DeploymentFQDN = $DeploymentFQDN
        GatewayFQDN = $GatewayFQDN
        EmailAddress = $EmailAddress
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$EmailAddress
	)
	
    $subdomain = $GatewayFQDN.Split(".")[0]
    
    $domainBody = @{
        "CNAME" = $DeploymentFQDN
            "Tags" = @{
                "email" = $EmailAddress
         }
    }

    $emailBody = @{
        "EmailAddress" = $EmailAddress
    }

    $result = Invoke-WebRequest "$domainUrl/$subdomain" -Method Put -Body ($domainBody | ConvertTo-Json) -ContentType "application/json" -UseBasicParsing
    $result = Invoke-WebRequest "$emailUrl/$subdomain" -Method Put -Body ($emailBody | ConvertTo-Json) -ContentType "application/json" -UseBasicParsing

}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$EmailAddress
	)
	
    $subdomain = $GatewayFQDN.Split(".")[0]

    $result = Invoke-WebRequest "$domainUrl/$subdomain" -UseBasicParsing
    $json = $result.Content | ConvertFrom-Json

    return ($json.Tags -and ($json.Tags.email -eq $EmailAddress))
}

Export-ModuleMember -Function *-TargetResource

