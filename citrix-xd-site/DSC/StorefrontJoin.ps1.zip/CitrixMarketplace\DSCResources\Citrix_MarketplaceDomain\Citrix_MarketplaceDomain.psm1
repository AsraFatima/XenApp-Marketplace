$domainUrl = "http://citrixxenappconfig.azurewebsites.net/api/domain"
$emailUrl = "http://citrixxenappconfig.azurewebsites.net/api/email"

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN
	)

	$returnValue = @{
        DeploymentFQDN = $DeploymentFQDN
        GatewayFQDN = $GatewayFQDN
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN
	)
	
    $subdomain = $GatewayFQDN.Split(".")[0]
    
    $domainBody = @{
        "CNAME" = $DeploymentFQDN
    }

    $result = Invoke-WebRequest "$domainUrl/$subdomain" -Method Put -Body ($domainBody | ConvertTo-Json) -ContentType "application/json" -UseBasicParsing
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeploymentFQDN,

        [parameter(Mandatory = $true)]
		[System.String]
		$GatewayFQDN
	)
	
    $subdomain = $GatewayFQDN.Split(".")[0]
    
    $result = Invoke-WebRequest "$domainUrl/$subdomain" -UseBasicParsing
    $json = $result.Content | ConvertFrom-Json
    
    Write-Verbose "Completed domain mapping"

    return ($json.CNAME -eq $DeploymentFQDN)
}

Export-ModuleMember -Function *-TargetResource

