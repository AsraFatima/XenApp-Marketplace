. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)

	$returnValue = @{
		Filename = $Filename
        NetscalerIP = $NetscalerIP
		Base64Data = $Base64Data
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
    
	if(-not $LocalPath)
	{
		return
	}
	
	if($UseHttps)
	{
		Set-Protocol "HTTPS"
	}
	else
	{
		Set-Protocol "HTTP"
	}
	
    if($Ensure -eq "Present")
    {
		$username = $NetscalerCredential.UserName
		$password  = $NetscalerCredential.GetNetworkCredential().password

		Invoke-NetscalerPSCP -Hostname $NetscalerIP -Username $username -Password $password -Local $LocalPath -Target $Filename
    }
    else 
    {
        Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "rm $Filename"
    }

    if($Reboot)
    {
        # Expect underlying connection to close
        try {
            Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session | Out-Null
        } catch { }

        Start-Sleep -Seconds (60*2)
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$LocalPath,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
	
	if(-not $LocalPath)
	{
		return $true
	}

	$username = $NetscalerCredential.UserName
	$password = $NetscalerCredential.GetNetworkCredential().password
	
	$path = (Split-Path -Path $Filename).Replace("\", "/")
	$name = Split-Path -Path $Filename -Leaf
	
    $output = Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "ls $path"
	
    if($Ensure -eq "Present")
    {
    	$present = (-not (($output | ?{$_ -match $name }) -eq $null))
		
		if($present) 
		{
			$wc = Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "wc -c $path"
			
			if($wc -match '([0-9]+)') 
			{
				$bytes = [int]$matches[0]
				$localBytes = (get-item $LocalPath | get-content -Encoding Byte | measure-object).Count
				
				if($bytes -ne $localBytes)
				{
					return $false
				}
			}
		}
		
		return $present
    }
    else 
    {
    	return ((($output | ?{$_ -match $name }) -eq $null))
    }
}

Export-ModuleMember -Function *-TargetResource

