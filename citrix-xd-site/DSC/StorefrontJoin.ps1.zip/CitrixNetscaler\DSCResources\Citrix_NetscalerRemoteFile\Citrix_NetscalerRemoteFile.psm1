. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$FileUri,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)

	$returnValue = @{
		Filename = $Filename
        NetscalerIP = $NetscalerIP
		Base64Data = $Base64Data
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$FileUri,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
    
	if(-not $FileUri)
	{
		return
	}
	
	if($UseHttps)
	{
		Set-Protocol "HTTPS"
	}
	else
	{
		Set-Protocol "HTTP"
	}
	
    if($Ensure -eq "Present")
    {
        $tempFile = [System.IO.Path]::GetTempFileName()
        try
        {
            Invoke-WebRequest $FileUri -OutFile $tempFile

	        $username = $NetscalerCredential.UserName
	        $password  = $NetscalerCredential.GetNetworkCredential().password
	
            Invoke-NetscalerPSCP -Hostname $NetscalerIP -Username $username -Password $password -Local $tempFile -Target $Filename

            Remove-Item $tempFile
        } 
        catch 
        {
            if(Test-Path $tempFile)
            {
                Remove-Item $tempFile
            }
        }
    }
    else 
    {
        Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "rm $Filename"
    }

    if($Reboot)
    {
        # Expect underlying connection to close
        try {
            Restart-NetScalerVpx -NSIP $NetscalerIP -SaveNSConfig -WebSession $session | Out-Null
        } catch { }

        Start-Sleep -Seconds (60*2)
    }
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
		[System.String]
		$Filename,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$FileUri,
          
		[System.Boolean]
		$Reboot = $false,

		[System.Boolean]
		$UseHttps = $false,

        [parameter(Mandatory = $true)]
		[ValidateSet("Present","Absent")]
		[System.String]
		$Ensure
	)
	
	if(-not $FileUri)
	{
		return $true
	}

	$username = $NetscalerCredential.UserName
	$password = $NetscalerCredential.GetNetworkCredential().password
	
	$path = (Split-Path -Path $Filename).Replace("\", "/")
	$name = Split-Path -Path $Filename -Leaf
	
    $output = Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "ls $path"
	
    if($Ensure -eq "Present")
    {
    	$present = (-not (($output | ?{$_ -match $name }) -eq $null))
		
		if($present) 
		{
			$wc = Invoke-NetscalerSSH -Hostname $NetscalerIP -Username $username -Password $password -Commands "wc -c $path"
			
			if($wc -match '([0-9]+)') 
			{
				$bytes = [int]$matches[0]
				$remoteBytes = (Invoke-WebRequest $FileUri -UseBasicParsing).RawContentLength
				
				if($bytes -ne $remoteBytes)
				{
					return $false
				}
			}
		}
		
		return $present
    }
    else 
    {
    	return ((($output | ?{$_ -match $name }) -eq $null))
    }
}

Export-ModuleMember -Function *-TargetResource

