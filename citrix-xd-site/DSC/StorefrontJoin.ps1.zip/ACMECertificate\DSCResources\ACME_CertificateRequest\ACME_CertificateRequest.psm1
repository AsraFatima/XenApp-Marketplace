Import-Module ACMEPowerShell

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
         [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath

	)


	$returnValue = @{
        CommonName = $CommonName
        ACMEServer = $ACMEServer
        EmailAddress = $EmailAddress
        VaultPath = $VaultPath
        IISPath = $IISPath
		PairPath = $PairPath
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
         [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath
	)
    
    Write-Verbose $CommonName
    Write-Verbose $ACMEServer
    Write-Verbose $EmailAddress
    Write-Verbose $CertificatePassword
    Write-Verbose $VaultPath
    Write-Verbose $IISPath
    Write-Verbose $CertPath
    Write-Verbose $KeyPath
    Write-Verbose $PairPath

    $json = @"
    {
  "Provider": {
    "`$type": "ACMESharp.WebServer.IisSitePathProvider, ACMESharp",

    // WebSiteRoot is the required path to the root directory of the target
    // IIS Web site where the content of the challenge response will be saved.
    "WebSiteRoot": "$IISPath"
  }
}
"@

    $retries = 10
    $delay = 10
    
    New-Item $VaultPath -ItemType Directory

    cd $VaultPath

    Initialize-ACMEVault -BaseURI $ACMEServer

    New-ACMERegistration -Contacts "mailto:$EmailAddress"

    Update-ACMERegistration -AcceptTOS

    New-ACMEIdentifier -Dns $CommonName -Alias dns1 -Label "NetScaler domain" -Memo "NetScaler domain"

    New-ACMEProviderConfig -WebServerProvider IisSitePath -Alias iisSiteHttpProvider -EditWith "powershell.exe"

    Get-Item $VaultPath\10-PRVDR\*.json | %{ $json | Set-Content -Path $_.FullName }

    Complete-ACMEChallenge -Ref dns1 -Challenge http-01 -ProviderConfig iisSiteHttpProvider
    Submit-ACMEChallenge -Ref dns1 -Challenge http-01

    Write-Verbose "Submitted"

    $tries = 0

    Start-Sleep -Seconds $delay

    while ((Update-ACMEIdentifier -Ref dns1).Status -ne "valid")
    {
        Write-Verbose (Update-ACMEIdentifier -Ref dns1).Status

        $tries = $tries + 1

        if($tries -gt $retries)
        {
            Throw "Could not complete domain verification challenge"
        }

        Start-Sleep -Seconds $delay
    }

    New-ACMECertificate -Identifier dns1 -Alias cert1 -Generate
    
    Submit-ACMECertificate -Ref cert1
    
    $tries = 0

    while ((Update-ACMECertificate -Ref cert1).CertificateRequest.StatusCode -ne "OK")
    {
        Write-Verbose (Update-ACMECertificate -Ref cert1).CertificateRequest.StatusCode

        $tries = $tries + 1

        if($tries -gt $retries)
        {
            Throw "Failed getting certificate from Let's Encrypt"
        }

        Start-Sleep -Seconds $delay
    }

    Get-ACMECertificate -Ref cert1 -ExportKeyPEM $KeyPath -ExportCertificatePEM $CertPath -CertificatePassword $CertificatePassword.GetNetworkCredential().Password
	
	Get-Content $CertPath | Add-Content $PairPath
	"`n" | Add-Content $PairPath
	Get-Content $KeyPath | Add-Content $PairPath
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CommonName,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$ACMEServer,

        [ValidateNotNullOrEmpty()]
		[System.String]
		$EmailAddress,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Management.Automation.PSCredential]
		$CertificatePassword,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VaultPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$IISPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$CertPath,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$KeyPath,
		
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$PairPath
	)
    
    Write-Verbose $VaultPath

    Test-Path $VaultPath
}

Export-ModuleMember -Function *-TargetResource

