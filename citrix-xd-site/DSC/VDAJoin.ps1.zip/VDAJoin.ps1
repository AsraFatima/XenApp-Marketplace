#
# VDAJoin.ps1
#
configuration VDAJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$Controller,

        [Parameter(Mandatory)]
        [String]$Director,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, PSDesiredStateConfiguration, CitrixXenDesktopAutomation

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    $explorerPath = "%ProgramFiles(x86)%\Internet Explorer\iexplore.exe"

    $director = "$explorerPath,http://$director/director,Director"
    $studio = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Citrix\Citrix Studio.lnk"

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $Controller
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[Registry]ListOfDDC" 
        }

        Citrix_XenDesktopVDA VDACatalog
        {
            XenDesktopController = $Controller
            CatalogName = "Administrative"
            DeliveryGroupName = "Administrative"
            PSDscRunAsCredential = $DomainCreds
            Users = @($DomainCreds.UserName)
            ApplicationShortcuts = @($studio, $director)
            DependsOn = "[xComputer]DomainJoin" 
        }
    }
} 
