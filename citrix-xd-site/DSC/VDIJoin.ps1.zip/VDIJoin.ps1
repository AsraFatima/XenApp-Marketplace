#
# VDIJoin.ps1
#
configuration VDIJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$Controller,

        [Parameter(Mandatory)]
        [String]$Director,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, PSDesiredStateConfiguration, CitrixXenDesktopAutomation

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    $gracePath = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod"

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $Controller
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
        
        Script RdGrace
        {
            SetScript = { 
                if(Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod")
                {
                    Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod" -Name *
                }
            }
            TestScript = { 
                if(Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod")
                {
                    $item = Get-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod"
                    return $item.Property.Count -eq 0
                }

                return $true
            }
            GetScript = { 
                return @{ Key = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM\GracePeriod" }
            }          
            DependsOn = "[Registry]ListOfDDC" 
        }

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[Script]RdGrace" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        Citrix_XenDesktopVDI VDACatalog
        {
            XenDesktopController = $Controller
            CatalogName = "Administrative Desktops"
            DeliveryGroupName = "Administrative Desktops"
            PSDscRunAsCredential = $DomainCreds
            Users = @($DomainCreds.UserName)
            ApplicationShortcuts = @("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Citrix\Citrix Studio.lnk")
            DependsOn = "[xComputer]DomainJoin" 
        }
    }
} 
