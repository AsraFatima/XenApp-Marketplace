#
# XDSite.ps1
#
configuration XDSite 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$ControllerName,

        [Parameter(Mandatory)]
        [String]$SiteName,

        [Parameter(Mandatory)]
        [String]$LicenseServer,

        [Parameter(Mandatory)]
        [String]$SQLServer,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, CitrixXenDesktopAutomation, xCertificate, xWebAdministration
 
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    $siteDatabaseName = "Citrix" + $SiteName + "Site"
    $monitoringDatabaseName = "Citrix" + $SiteName + "Monitoring"
    $loggingDatabaseName = "Citrix" + $SiteName + "Logging"
    $databaseInstance = ""

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        WindowsFeature InstallWebServer
        {
            Name = "Web-Server"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]ADPowershell"
        }
        
        WindowsFeature InstallWebAsp
        {
            Name = "Web-Asp-Net45"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebServer"
        }

        WindowsFeature InstallWebConsole
        {
            Name = "Web-Mgmt-Console"
            Ensure = "Present"
            DependsOn = "[WindowsFeature]InstallWebAsp"
        }

		xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]InstallWebConsole" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = "$($ControllerName).$($DomainName)"
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $ControllerName; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }
        
        Citrix_XenDesktopDatabase CreateSiteDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Site"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $databaseInstance
            DatabaseName = $siteDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[xWebSite]DefaultWebSite"
        }

        Citrix_XenDesktopDatabase CreateLoggingDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Logging"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $databaseInstance
            DatabaseName = $loggingDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_XenDesktopDatabase]CreateSiteDatabase" 
        }

        Citrix_XenDesktopDatabase CreateMonitorDatabase
        {
            SiteName = $SiteName
            DatabaseClass = "Monitor"			
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $databaseInstance
            DatabaseName = $monitoringDatabaseName
            DatabaseCredential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Citrix_XenDesktopDatabase]CreateLoggingDatabase" 
        }

        Citrix_XenDesktopSite CreateSite
        {
            DatabaseServer = $SQLServer
            DatabaseServerInstance = $databaseInstance
            UserToMakeAdmin = $DomainCreds.UserName
            XenDesktopController = "localhost:80"
            SiteName = $SiteName
            LicenseServer = $LicenseServer
            LicenseServerPort = 27000
            LoggingDatabaseName = $loggingDatabaseName
            MonitoringDatabaseName = $monitoringDatabaseName
            SiteDatabaseName = $siteDatabaseName
            Ensure = "Present"
            DependsOn = "[Citrix_XenDesktopDatabase]CreateMonitorDatabase" 
        }
    }
} 
