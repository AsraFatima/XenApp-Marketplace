#
# ConfigureDirector.ps1
#
configuration ConfigureDirector
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$LicenseServer,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, CitrixXenDesktopAutomation, xCertificate, xWebAdministration

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xCertReq SSLCert
        {
            CARootName = 'DomainCA'
            CAServerFQDN = $DomainController
            Subject = "$($LicenseServer).$($DomainName)"
            AutoRenew = $true
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin"
        }

        xWebSite DefaultWebSite {
            Name = 'Default Web Site';
            PhysicalPath = 'C:\inetpub\wwwroot';
            BindingInfo = @(
                MSFT_xWebBindingInformation  { Protocol = 'HTTPS'; Port = 443; CertificateThumbprint = $LicenseServer; CertificateStoreName = 'My'; }
                MSFT_xWebBindingInformation  { Protocol = 'HTTP'; Port = 80; }
            )
            DependsOn = '[xCertReq]SSLCert';
        }

        Citrix_XenDesktopDirector Director
        {
            XenDesktopController = $DeliveryController
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[xWebSite]DefaultWebSite" 
        }
    }
} 
