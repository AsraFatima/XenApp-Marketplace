#
# XDSite.ps1
#
configuration XDSite 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$SiteName,

        [Parameter(Mandatory)]
        [String]$LicenseServer,

        [Parameter(Mandatory)]
        [String]$SQLServer,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, CitrixXenDesktopAutomation, CitrixXenDesktop7, xCredSSP, xWindowsUpdate
 
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    
    $siteDatabaseName = "Citrix" + $SiteName + "Site"
    $monitoringDatabaseName = "Citrix" + $SiteName + "Monitoring"
    $loggingDatabaseName = "Citrix" + $SiteName + "Logging"

    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xCredSSP CredSSPServer {
            Ensure = "Present"
            Role = "Server"
            DependsOn = "[WindowsFeature]ADPowershell" 
        }    

        xCredSSP CredSSPClient {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*"
            DependsOn = "[xCredSSP]CredSSPServer" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xCredSSP]CredSSPClient"
        }

        XD7Database CreateSiteDatabase
        {
            SiteName = $SiteName
            DataStore = "Site"			
            DatabaseServer = $SQLServer
            DatabaseName = $siteDatabaseName
            Credential = $DomainCreds
            DependsOn = "[xComputer]DomainJoin" 
        }

        XD7Database CreateLoggingDatabase
        {
            SiteName = $SiteName
            DataStore = "Logging"			
            DatabaseServer = $SQLServer
            DatabaseName = $loggingDatabaseName
            Credential = $DomainCreds
            DependsOn = "[XD7Database]CreateSiteDatabase" 
        }

        XD7Database CreateMonitorDatabase
        {
            SiteName = $SiteName
            DataStore = "Monitor"			
            DatabaseServer = $SQLServer
            DatabaseName = $monitoringDatabaseName
            Credential = $DomainCreds
            DependsOn = "[XD7Database]CreateLoggingDatabase" 
        }

        Citrix_XenDesktopSite CreateSite
        {
            DatabaseServer = $SQLServer
            DatabaseServerInstance = ""
            UserToMakeAdmin = $DomainCreds.UserName
            XenDesktopController = "localhost:80"
            SiteName = $SiteName
            LicenseServer = $LicenseServer
            LicenseServerPort = 27000
            LoggingDatabaseName = $loggingDatabaseName
            MonitoringDatabaseName = $monitoringDatabaseName
            SiteDatabaseName = $siteDatabaseName
            Ensure = "Present"
            DependsOn = "[XD7Database]CreateMonitorDatabase" 
        }
    }
} 
