#
# StorefrontJoin.ps1
#
configuration StorefrontJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, xCredSSP, xWindowsUpdate #, CitrixXenDesktopAutomation

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        <#
        xHotfix WMFInstall
        {
            Uri = 'http://ctxartifacts.blob.core.windows.net/hotfix/W2K12-KB3066438-x64.msu'
            Id = 'KB2969050'
            Ensure = 'Present'
            DependsOn = "[WindowsFeature]ADPowershell" 
        }
        #>

        xCredSSP CredSSPServer {
            Ensure = "Present"
            Role = "Server"
            DependsOn = "[WindowsFeature]ADPowershell" 
        }    

        xCredSSP CredSSPClient {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*"
            DependsOn = "[xCredSSP]CredSSPServer" 
        }
 
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xCredSSP]CredSSPClient" 
        }
        <#
        Citrix_XenDesktopStorefront Storefront
        {
            XenDesktopController = "ddc"
            SiteName = "TestSite"
            Transport = "HTTP"
            Port = 80
            Credential = $DomainCreds
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin" 
        }#>
    }
} 
