#
# StorefrontJoin.ps1
#
configuration StorefrontJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Parameter(Mandatory)]
        [String]$NetscalerIP,

        [Parameter(Mandatory)]
        [String]$License,

        [Parameter(Mandatory)]
        [String]$Certificate,

        [Parameter(Mandatory)]
        [String]$CertificateKey,

        [Parameter(Mandatory)]
        [String]$AuthorityCertificate1,

        [Parameter(Mandatory)]
        [String]$AuthorityCertificate2,

        [Parameter(Mandatory)]
        [String]$DomainController,

        [Parameter(Mandatory)]
        [String]$StorefrontServer,

        [Parameter(Mandatory)]
        [String]$DeliveryController,

        [Parameter(Mandatory)]
        [String]$VirtualServerName,

        [Parameter(Mandatory)]
        [String]$GatewayName,

        [Parameter(Mandatory)]
        [String]$FQDN,

        [Parameter(Mandatory)]
        [Int]$VirtualServerPort,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, xCredSSP, xWindowsUpdate, CitrixNetscaler , CitrixXenDesktopAutomation

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 
   
        xCredSSP CredSSPServer {
            Ensure = "Present"
            Role = "Server"
            DependsOn = "[WindowsFeature]ADPowershell" 
        }    

        xCredSSP CredSSPClient {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*"
            DependsOn = "[xCredSSP]CredSSPServer" 
        }
 
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xCredSSP]CredSSPClient" 
        }
        
        Citrix_NetscalerFile License 
        {
            Filename = "/nsconfig/license/license.lic"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $License
            Reboot = $true
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin" 
        }
        
        Citrix_NetscalerFile Certificate 
        {
            Filename = "/nsconfig/ssl/certificate.cert"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $Certificate
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerFile]License"
        }

        Citrix_NetscalerFile CertificateKey
        {
            Filename = "/nsconfig/ssl/certificate.key"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $CertificateKey
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerFile]Certificate"
        }

        Citrix_NetscalerFile Authority1 
        {
            Filename = "/nsconfig/ssl/authority1.cert"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $AuthorityCertificate1
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerFile]CertificateKey"
        }

        Citrix_NetscalerFile Authority2 
        {
            Filename = "/nsconfig/ssl/authority2.cert"
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            Base64Data = $AuthorityCertificate2
            Ensure = "Present"
            DependsOn = "[Citrix_NetscalerFile]Authority1"
        }

        Citrix_NetscalerConfigureXD NSConfig 
        {
            NetscalerIP = $NetscalerIP
            NetscalerCredential = $Admincreds
            DomainCredential = $Admincreds
            DomainName = $DomainName
            DomainController= $DomainController
            StorefrontServer = $StorefrontServer
            DeliveryController = $DeliveryController
            VirtualServerName = $VirtualServerName
            VirtualServerPort = $VirtualServerPort
        }

        Citrix_XenDesktopStorefront Storefront
        {
            XenDesktopController = "ddc"
            StorefrontServer = $StorefrontServer
            FQDN = $FQDN
            GatewayName = $GatewayName
            SiteName = "TestSite"
            Transport = "HTTP"
            Port = 80
            DependsOn = "[Citrix_NetscalerConfigureXD]NSConfig" 
        }
    }
} 
