. "$PSScriptRoot\..\NetScalerConfiguration.ps1"

function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort
	)

	$returnValue = @{
        NetscalerIP = $NetscalerIP
	}

	$returnValue
}

function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort
	)
	
	$VirtualServerIP = $NetscalerIP

	$username = $NetscalerCredential.UserName
	$password = $DomainCredential.GetNetworkCredential().Password

	$domainUsername = $DomainCredential.UserName
	$domainPassword = $DomainCredential.GetNetworkCredential().Password

	$domainBase = [string]::Join(",", ($DomainName.Split(".") | %{"dc=$_"}))

	Set-Protocol "HTTP"

	$session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password

	Enable-NSVPXFeature -NSIP $NetScalerIP -Features "sslvpn ssl responder loadbalancing" -WebSession $session

	Add-DNSServer -NSIP $NetScalerIP -DNSServerIP $DomainController -WebSession $session
	Add-DNSServer -NSIP $NetScalerIP -DNSServerIP $GoogleDNS -WebSession $session

	Add-CertKeyPair -NSIP $NetScalerIP -CertKeyName "wildcard" -CertPath "/nsconfig/ssl/certificate.cert" -KeyPath "/nsconfig/ssl/certificate.key" -CertKeyFormat PEM -Passcrypt "luVJAUxtmUY=" -WebSession $session 
	Add-RootCert -NSIP $NetScalerIP -CertName "authority1" -CertPath "/nsconfig/ssl/authority1.cert" -CertKeyFormat PEM -WebSession $session
	Add-RootCert -NSIP $NetScalerIP -CertName "authority2" -CertPath "/nsconfig/ssl/authority2.cert" -CertKeyFormat PEM -WebSession $session

	Add-LDAPAction -NSIP $NetScalerIP -LDAPActionName "$($DomainController)_LDAP" -LDAPServerIP "$($DomainController)" -LDAPBaseDN $($domainBase) -LDAPBindDN "$domainUsername@$($DomainName)" -LDAPBindDNPassword $($domainPassword) -LDAPLoginName $($LDAPLoginName) -WebSession $session | out-null
	Add-LDAPPolicy -NSIP $NetScalerIP -LDAPActionName "$($DomainController)_LDAP" -LDAPPolicyName "$($DomainController)_LDAP_pol" -LDAPRuleExpression NS_TRUE -WebSession $session

	Add-VServer -NSIP $NetScalerIP -VServerName $($VirtualServerName) -VServerIP $($VirtualServerIP) -VServerPort $VirtualServerPort -WebSession $session
	New-VServeSSLCertKeyBinding -NSIP $NetScalerIP -CertKeyName "wildcard" -VServerName $($VirtualServerName) -WebSession $session
	New-VServerLDAPPolicyBinding -NSIP $NetScalerIP -VServerName $($VirtualServerName) -LDAPPolicyName "$($DomainController)_LDAP_pol" -WebSession $session
	Set-NetScalerSFStore -NSIP $($NetScalerIP) -VirtualServerName $($VirtualServerName) -VirtualServerIP $($VirtualServerIP) -StoreFrontServer $StorefrontServer -STAServerURL "http://$DeliveryController" -SingleSignOnDomain $($DomainName) -WebSession $session|out-null
}

function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$NetscalerIP,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$NetscalerCredential,

        [parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$DomainCredential,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DomainController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$StorefrontServer,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$DeliveryController,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.String]
		$VirtualServerName,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
		[System.Int32]
		$VirtualServerPort
	)
	
	$session = Connect-NSVPX -NSIP $NetScalerIP -NSUserName $username -NSPassword $password
	$json = Get-DNSServer -NSIP $NetscalerIP -WebSession $session
	
	return (-not (($job.dnsnameserver | ?{$_.ip -match $DomainController }) -eq $null))
}

Export-ModuleMember -Function *-TargetResource

