#
# VDAJoin.ps1
#
configuration VDAJoin 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
       
        [Parameter(Mandatory)]
        [String]$Controller,

        [Int]$RetryCount = 50,
        [Int]$RetryIntervalSec = 60
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, xPsDesiredStateConfiguration, PSDesiredStateConfiguration

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
        LocalConfigurationManager 
        { 
            RebootNodeIfNeeded = $true
        } 

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        Registry ListOfDDC
        {
            Ensure = "Present"
            Key = "HKEY_LOCAL_MACHINE\Software\Citrix\VirtualDesktopAgent"
            ValueName = "ListOfDDCs"
            ValueData = $Controller
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[Registry]ListOfDDC" 
        }
    }
} 
