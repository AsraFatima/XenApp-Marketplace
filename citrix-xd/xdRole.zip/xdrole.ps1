Configuration xdServerRole
{
    Param
    (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $mediaUri,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("Controller", "Storefront", "License", "Director", "DesktopVDA", "SessionVDA", ignorecase=$true)]
        [String]$xdRoleType
    )

    Import-DscResource -Module CitrixXenDesktop
    Import-DscResource -Module xPsDesiredStateConfiguration

    Node localhost
    {

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        File citrixFolder
        {
            Ensure = 'Present'
            Type = 'Directory'
            DestinationPath = "$env:programdata\Citrix\EasyButton"
        }

        xRemoteFile xdMedia
        {
            DestinationPath = "$env:programdata\Citrix\XenDesktop75.zip"
            Uri = $mediaUri
            DependsOn = "[File]citrixFolder"
        }

        Archive xdMediaUnzip
        {
            Ensure = "Present"
            Path = "$env:programdata\Citrix\XenDesktop75.zip"
            Destination = "$env:ProgramData\Citrix"
            DependsOn = "[xRemoteFile]xdMedia"
        }

        Citrix_XenDesktopRole xdRole
        {
            Ensure = "Present"
            XenDesktopRole = $xdRoleType
            XenDesktopMediaPath = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[Archive]xdMediaUnzip"
        }
    }
}
