﻿configuration ConfigureDDC 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
		
		[parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $mediaUri,

        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("Controller", "Storefront", "License", "Director", "DesktopVDA", "SessionVDA", ignorecase=$true)]
        [String]$xdRoleType,
		
        [Int]$RetryCount = 20,
        [Int]$RetryIntervalSec = 30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xComputerManagement, CitrixXenDesktop, xPsDesiredStateConfiguration

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {
		LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }
		
        File citrixFolder
        {
            Ensure = 'Present'
            Type = 'Directory'
            DestinationPath = "$env:programdata\Citrix\EasyButton"
			DependsOn = "[xComputer]DomainJoin"
        }

        xRemoteFile xdMedia
        {
            DestinationPath = "$env:programdata\Citrix\XenDesktop75.zip"
            Uri = $mediaUri
            DependsOn = "[File]citrixFolder"
        }

        Archive xdMediaUnzip
        {
            Ensure = "Present"
            Path = "$env:programdata\Citrix\XenDesktop75.zip"
            Destination = "$env:ProgramData\Citrix"
            DependsOn = "[xRemoteFile]xdMedia"
        }

        Citrix_XenDesktopRole xdRole
        {
            Ensure = "Present"
            XenDesktopRole = $xdRoleType
            XenDesktopMediaPath = "$env:ProgramData\Citrix\7.5"
            DependsOn = "[Archive]xdMediaUnzip"
        }
   }
} 
